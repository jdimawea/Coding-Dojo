function newPic() {
    document.getElementById("plant").src="succulents-2.jpg";
}

function oldPic() {
    document.getElementById("plant").src="succulents-1.jpg";
}

function hide() {
    document.getElementById("cookiebox").remove;
}